| `Version` | `Update Notes`                                        |
|-----------|-------------------------------------------------------|
| 1.0.1     | - Each attack uses 5% of max stamina to help balance. |
| 1.0.0     | - Initial Release                                     |